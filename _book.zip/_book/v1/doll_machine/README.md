# 在线娃娃机

### 简介

anyRTC提供在线抓娃娃机场景的支持，RTCWaWaJiEngine SDK 提供极简接口，实现多平台快速接入。

### Demo体验

请根据需求选择渠道安装，安装完娃娃机 Demo后，可体验在线实时抓娃娃功能。

- [Web Demo体验](http://wawaji.anyrtc.cc/)

### 源码GitHub

源码仅供开发者参考，适用于SDK调试，便于快速集成。

- [iOS Demo 源码下载](https://github.com/anyRTC/anyRTC-WaWa-Client-iOS)

- [Android Demo 源码下载](https://github.com/anyRTC/anyRTC-WaWa-Client-Android)

- [Web Demo 源码下载](https://github.com/anyRTC/anyRTC-WaWa-Client-Web)
